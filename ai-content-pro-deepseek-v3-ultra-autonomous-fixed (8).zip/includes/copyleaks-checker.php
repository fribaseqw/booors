<?php
// Copyleaks ile içerik özgünlük kontrolü

function copyleaks_check_content($content) {
    $api_key = get_option('copyleaks_api_key');
    $endpoint = 'https://api.copyleaks.com/v3/education/scan';

    $payload = json_encode(['base64' => base64_encode($content)]);

    $response = wp_remote_post($endpoint, [
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key
        ],
        'body' => $payload
    ]);

    if (is_wp_error($response)) {
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    $result = json_decode($body, true);

    return $result['results'] ?? false;
}
