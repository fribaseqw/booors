<?php
class UnsplashImageFetcher {
    private $access_key = 'YOUR_UNSPLASH_ACCESS_KEY';

    public function fetchImage($query) {
        $url = "https://api.unsplash.com/photos/random?query=" . urlencode($query) . "&client_id=" . $this->access_key;
        $response = file_get_contents($url);
        $data = json_decode($response, true);
        return $data['urls']['regular'] ?? '';
    }
}
?>