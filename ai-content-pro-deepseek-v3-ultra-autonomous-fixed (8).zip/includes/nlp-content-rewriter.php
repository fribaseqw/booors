
<?php
function rewrite_with_ai($content) {
    $api_key = get_option('openai_api_key');
    $prompt = "Rewrite the following content to be 100% unique and natural sounding:\n\n" . $content;
    $response = wp_remote_post("https://api.openai.com/v1/chat/completions", array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json'
        ),
        'body' => json_encode(array(
            'model' => 'gpt-4',
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'temperature' => 0.7
        ))
    ));
    if (is_wp_error($response)) return $content;
    $body = json_decode(wp_remote_retrieve_body($response), true);
    return $body['choices'][0]['message']['content'] ?? $content;
}
?>
