<?php
require_once("deepseek-api.php");
require_once("reddit-fetcher.php");
require_once("quora-fetcher.php");
require_once("nlp-content-rewriter.php");
require_once("plagiarism-checker.php");
require_once("content-generator.php");
require_once("post-publisher.php"); // YAYINLAMA fonksiyonu burada

function generate_full_article($category) {
    $keywords = get_deepseek_keywords($category);
    $reddit_titles = get_reddit_topics($category);
    $quora_topics = get_quora_topics($category);

    $title = $reddit_titles[0] ?? $quora_topics[0] ?? "AI Generated Article";
    $content = generate_content($title, $keywords);
    $unique = check_plagiarism($content);

    $retry = 0;
    while (!$unique && $retry < 3) {
        $content = rewrite_with_ai($content);
        $unique = check_plagiarism($content);
        $retry++;
    }

    // ✅ Yayınlama işlemi burada gerçekleşiyor
    if (!empty($content)) {
        $post_id = ai_publish_post($title, $content); // category_id istersen buraya eklenebilir
        if (!$post_id) {
            error_log("❌ Yayınlama başarısız: {$title}");
        } else {
            error_log("✅ Yayınlandı: {$title} (ID: $post_id)");
        }
    } else {
        error_log("⚠️ İçerik boş geldi, yayınlanamadı: {$title}");
    }

    return [
        'title' => $title,
        'content' => $content,
        'keywords' => $keywords
    ];
}
?>
