
<?php
function fetch_competitor_content($keyword) {
    $api_key = get_option('semrush_api_key');
    $url = "https://api.semrush.com/?type=url_organic&key=$api_key&domain=$keyword.com&export_columns=Ph,Po";
    $response = wp_remote_get($url);
    if (is_wp_error($response)) return [];
    $body = wp_remote_retrieve_body($response);
    $lines = explode("\n", $body);
    return array_slice($lines, 1, 5); // İlk 5 farkı al
}
?>
