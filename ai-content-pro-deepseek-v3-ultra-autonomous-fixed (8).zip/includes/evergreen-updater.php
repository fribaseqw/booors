
<?php
// Cron ile zamanla içerik güncelleme
function evergreen_update_articles() {
    $args = array('post_type' => 'post', 'posts_per_page' => 10);
    $posts = get_posts($args);
    foreach ($posts as $post) {
        $original = $post->post_content;
        $updated = deepseek_rewrite($original, 'evergreen');
        wp_update_post(array(
            'ID' => $post->ID,
            'post_content' => $updated
        ));
    }
}
add_action('evergreen_update_hook', 'evergreen_update_articles');
if (!wp_next_scheduled('evergreen_update_hook')) {
    wp_schedule_event(time(), 'daily', 'evergreen_update_hook');
}
?>
