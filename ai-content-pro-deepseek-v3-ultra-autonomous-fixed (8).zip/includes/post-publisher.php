<?php
// post-publisher.php - Gelişmiş içerik bot modülü

/**
 * WordPress'te yeni bir yazı yayınlar
 *
 * @param string $title       Yazı başlığı
 * @param string $content     Yazı içeriği (AI tarafından oluşturulan)
 * @param int|null $category_id Kategori ID'si (isteğe bağlı)
 * @return int|false          Yayınlanan yazının ID'si veya başarısızlık durumunda false
 */
function ai_publish_post($title, $content, $category_id = null) {
    if (empty($content)) {
        error_log('🛑 [AI Publisher] İçerik boş geldi, yazı eklenmedi.');
        return false;
    }

    // Yazı verilerini hazırla
    $post_data = array(
        'post_title'    => wp_strip_all_tags($title),
        'post_content'  => $content,
        'post_status'   => 'publish', // otomatik olarak yayınla
        'post_author'   => 1,         // admin ID (isteğe göre değiştirilebilir)
        'post_category' => $category_id ? array($category_id) : array(),
        'post_type'     => 'post',
    );

    // Yazıyı ekle
    $post_id = wp_insert_post($post_data);

    if (is_wp_error($post_id)) {
        error_log('❌ [AI Publisher] Yazı eklenemedi: ' . $post_id->get_error_message());
        return false;
    }

    error_log('✅ [AI Publisher] İçerik başarıyla yayınlandı. Post ID: ' . $post_id);
    return $post_id;
}
