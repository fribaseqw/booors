
<?php
function apply_humanizer_mask($text) {
    $deyimler = ['bir taşla iki kuş vurmak', 'saman altından su yürütmek'];
    $yorumlar = ['Okurken insan kendini olayın içinde hissediyor.', 'Bu konuyu yıllardır merak ediyordum.'];
    shuffle($deyimler);
    shuffle($yorumlar);
    $text .= "\n\n" . $deyimler[0] . ". " . $yorumlar[0];
    return $text;
}
?>
