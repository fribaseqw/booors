
<?php
// Sosyal Medya Post Dönüştürücü
function generate_social_posts($title, $content) {
    $twitter = substr($title . ' - ' . strip_tags($content), 0, 280);
    $linkedin = "<h3>$title</h3><p>" . substr(strip_tags($content), 0, 500) . "...</p>";
    return ['twitter' => $twitter, 'linkedin' => $linkedin];
}
?>
