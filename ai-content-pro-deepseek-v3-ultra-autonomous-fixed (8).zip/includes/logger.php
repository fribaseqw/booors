<?php
// logger.php - Gelişmiş içerik bot modülü
