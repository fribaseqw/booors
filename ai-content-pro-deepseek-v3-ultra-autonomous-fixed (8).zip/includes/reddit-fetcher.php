
<?php
function get_reddit_topics($subreddit) {
    $url = "https://www.reddit.com/r/" . urlencode($subreddit) . "/top.json?limit=5";
    $response = wp_remote_get($url, array(
        'headers' => array('User-Agent' => 'WP-ContentBot/1.0')
    ));
    if (is_wp_error($response)) return [];
    $body = json_decode(wp_remote_retrieve_body($response), true);
    $titles = [];
    foreach ($body['data']['children'] as $post) {
        $titles[] = $post['data']['title'];
    }
    return $titles;
}
?>
