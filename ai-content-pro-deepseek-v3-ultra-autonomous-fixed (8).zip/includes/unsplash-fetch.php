<?php
// Unsplash görsel alma fonksiyonu

function fetch_unsplash_image($query) {
    $access_key = get_option('unsplash_api_key');
    $url = "https://api.unsplash.com/photos/random?query=" . urlencode($query) . "&client_id=" . $access_key;

    $response = wp_remote_get($url);
    if (is_wp_error($response)) {
        return null;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    return $data['urls']['regular'] ?? null;
}
