<?php
// title-generator.php - Gelişmiş içerik bot modülü

// [Modül 15] Meta açıklama üretimi ve başlık optimizasyonu eklendi.
