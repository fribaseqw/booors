<?php
// DeepSeek içerik üretim motoru

function deepseek_generate_content($topic) {
    $api_key = get_option('deepseek_api_key');
    $endpoint = 'https://api.deepseek.com/generate';
    $payload = json_encode([
        'prompt' => $topic,
        'length' => 700,
        'language' => 'tr',
        'temperature' => 0.9
    ]);

    $response = wp_remote_post($endpoint, [
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key
        ],
        'body' => $payload
    ]);

    if (is_wp_error($response)) {
        return 'Hata: İçerik üretilemedi.';
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

   return $data['choices'][0]['message']['content'] ?? 'İçerik alınamadı.';

}
