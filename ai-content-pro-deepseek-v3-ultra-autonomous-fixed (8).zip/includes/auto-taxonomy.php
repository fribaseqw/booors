
<?php
// AI Kategori & Etiket Önerici
function suggest_categories_and_tags($content) {
    $categories = [];
    $tags = [];

    // Basit anahtar kelime analizine dayalı öneri sistemi
    if (strpos($content, 'teknoloji') !== false) {
        $categories[] = 'Teknoloji';
        $tags = array_merge($tags, ['Yapay Zeka', 'Gelecek', 'Yenilik']);
    }
    if (strpos($content, 'sağlık') !== false) {
        $categories[] = 'Sağlık';
        $tags = array_merge($tags, ['Beslenme', 'Egzersiz', 'Zindelik']);
    }

    return ['categories' => $categories, 'tags' => $tags];
}
?>
