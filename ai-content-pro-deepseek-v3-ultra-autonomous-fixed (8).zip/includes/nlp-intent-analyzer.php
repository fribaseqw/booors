<?php
class NLPIntentAnalyzer {
    public function analyzeIntent($keyword) {
        $informational_keywords = ['nedir', 'nasıl', 'faydaları', 'tarihçesi', 'örnekleri'];
        $transactional_keywords = ['satın al', 'en iyi', 'fiyat', 'karşılaştırma'];

        foreach ($informational_keywords as $info) {
            if (stripos($keyword, $info) !== false) return 'informational';
        }
        foreach ($transactional_keywords as $trans) {
            if (stripos($keyword, $trans) !== false) return 'transactional';
        }
        return 'general';
    }

    public function generateTone($intent) {
        switch ($intent) {
            case 'informational': return 'Bilgilendirici ve açıklayıcı';
            case 'transactional': return 'İkna edici ve satış odaklı';
            default: return 'Nötr ve sade';
        }
    }
}
?>