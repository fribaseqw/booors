<?php
// schema-generator.php - Gelişmiş içerik bot modülü

// [Modül 14] Yoast & RankMath SEO schema uyumluluğu entegre edilmiştir.
