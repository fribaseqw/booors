
<?php
function turkish_nlp_optimize($content) {
    $deyimler = ['ayağını yorganına göre uzat', 'göz var nizam var'];
    $atasozleri = ['Azıcık aşım, kaygısız başım.', 'Sakla samanı, gelir zamanı.'];
    $varyasyonlar = ['çok önemli', 'epeyce değerli', 'bir hayli kıymetli'];

    $content = str_replace('önemli', $varyasyonlar[array_rand($varyasyonlar)], $content);
    $content .= "\n\nDeyim: " . $deyimler[array_rand($deyimler)];
    $content .= "\nAtasözü: " . $atasozleri[array_rand($atasozleri)];
    return $content;
}
?>
