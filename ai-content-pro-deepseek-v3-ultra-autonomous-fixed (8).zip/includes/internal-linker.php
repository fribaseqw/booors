<?php
// internal-linker.php - Gelişmiş içerik bot modülü
