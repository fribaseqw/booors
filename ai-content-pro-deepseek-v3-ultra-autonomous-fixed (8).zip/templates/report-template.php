<?php
// report-template.php - Gelişmiş içerik bot modülü
