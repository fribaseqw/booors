<?php
// Türkçe okuma kolaylığına göre puan verir
function readability_score($text) {
    $sentences = preg_split('/[.!?]+/', $text);
    $words = preg_split('/\s+/', $text);
    $score = 206.835 - 1.015 * (count($words)/max(count($sentences),1)) - 84.6 * average_syllables($words);
    return round($score, 2);
}

function average_syllables($words) {
    $total = 0;
    foreach ($words as $word) {
        $total += preg_match_all('/[aeiouıüöçş]/ui', $word);
    }
    return $total / max(count($words), 1);
}
?>