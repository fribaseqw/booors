<?php
// İçeriğe göre otomatik e-posta ile backlink alma
function generate_outreach_email($title, $excerpt) {
    return "Merhaba, içerik sayfamız '" . $title . "' hakkında bir bağlantı paylaşmanızı öneriyoruz. Özet: " . $excerpt;
}
?>