<?php
// Google E-E-A-T uyumlu uzman görüşü ve güven arttırıcı içerik ekler
function add_eat_paragraph($content, $author, $source) {
    $expert = "Bu konuda {$author} şöyle diyor: \"{$content}\"";
    $reference = "Daha fazla bilgi için kaynak: <a href='{$source}'>{$source}</a>";
    return $expert . "<br><br>" . $reference;
}
?>