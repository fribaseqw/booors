<?php
// Ton ayarlayıcı (resmi, samimi, eğlenceli)
function adjust_tone($text, $tone = 'formal') {
    if ($tone === 'friendly') {
        $text = str_replace(['Merhaba', 'Lütfen'], ['Selam!', 'Bi zahmet'], $text);
    } elseif ($tone === 'playful') {
        $text .= ' 🎉 Şimdi daha eğlenceli!';
    }
    return $text;
}
?>