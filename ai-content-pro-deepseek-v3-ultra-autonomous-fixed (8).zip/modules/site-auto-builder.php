<?php
// Otomatik site kurulum modülü: tema, kategori, menü tanımlamaları
function auto_setup_site() {
    return "Tema ve kategoriler başarıyla kuruldu.";
}
?>