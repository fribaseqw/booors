<?php
// Aynı kategorideki yazılar arasında iç bağlantı kurar
function add_internal_links($content, $related_articles) {
    foreach ($related_articles as $title => $link) {
        if (strpos($content, $title) === false) {
            $content .= "<p><a href='$link'>İlgili: $title</a></p>";
        }
    }
    return $content;
}
?>