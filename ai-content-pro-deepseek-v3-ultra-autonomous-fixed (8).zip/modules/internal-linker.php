<?php
class InternalLinker {
    public static function link(&$content) {
        $content .= "\n\nDaha fazla bilgi için sitemizi ziyaret edin.";
    }
}
?>