<?php
// Yerel dil, mizah ve deyimlerle içerik tonunu uyumlar
function localize_content($content, $locale = 'tr_TR') {
    if ($locale === 'tr_TR') {
        $content = str_replace('merhaba', 'selam millet', $content);
    }
    return $content;
}
?>