<?php
class TaxonomyGenerator {
    public static function assign($content) {
        return ['kategori' => 'Teknoloji', 'etiketler' => ['ai', 'seo', 'içerik']];
    }
}
?>