<?php
class TrendsKeywordFetcher {
    public static function fetch() {
        return ['ai içerik üretimi', 'wordpress seo bot', 'trend blog fikirleri'];
    }
}
?>