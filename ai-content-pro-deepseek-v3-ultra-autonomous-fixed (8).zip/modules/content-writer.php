<?php
class ContentWriter {
    public static function generate($keyword) {
        $api_key = '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'; // kendi API anahtarını buraya yaz

        $postData = [
            "model" => "deepseek/deepseek-r1:free", // ✅ ücretsiz DeepSeek modeli
            "messages" => [
                ["role" => "system", "content" => "Sen SEO uzmanı bir içerik yazarı ve editörsün. Konuyla ilgili detaylı, özgün ve SEO uyumlu blog içeriği yaz."],
                ["role" => "user", "content" => "Lütfen '" . $keyword . "' konusu hakkında özgün bir blog yazısı üret."]
            ],
            "temperature" => 0.7,
            "max_tokens" => 1000
        ];

        $response = wp_remote_post('https://openrouter.ai/api/v1/chat/completions', [
            'method'  => 'POST',
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
                'HTTP-Referer'  => 'https://yerelkesif.com', // kendi domain adın
                'X-Title'       => 'AI Content Writer Plugin'
            ],
            'body'    => json_encode($postData),
            'timeout' => 120 // ⏱ free-tier yavaş olabilir
        ]);

        if (is_wp_error($response)) {
            error_log("🛑 API HATASI: " . $response->get_error_message());
            return "İçerik üretimi başarısız: API hatası";
        }

        $body_json = wp_remote_retrieve_body($response);
        $body = is_string($body_json) ? json_decode($body_json, true) : [];

        error_log("🔍 API JSON Cevabı: " . $body_json); // hata ayıklama için

        if (!isset($body['choices'][0]['message']['content'])) {
            error_log("❌ API dönüşü beklenen formatta değil: " . print_r($body, true));
            return "İçerik üretimi başarısız: Geçersiz yanıt";
        }

        return $body['choices'][0]['message']['content'];
    }
}
?>
