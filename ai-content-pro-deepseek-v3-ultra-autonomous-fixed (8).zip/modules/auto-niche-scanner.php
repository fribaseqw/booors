<?php
// Google Trends, News, Reddit, YouTube üzerinden trend başlıkları çeker
function get_trending_topics() {
    $sources = ['Google Trends', 'Reddit', 'YouTube', 'Google News'];
    $topics = ['Yapay Zeka', 'Kripto Para', 'E-Ticaret', 'Sağlıklı Yaşam'];
    return array_map(function($topic) {
        return "Trend Başlık: " . $topic;
    }, $topics);
}
?>