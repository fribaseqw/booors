<?php
class SeoMetaBuilder {
    public static function build($content) {
        return ['meta_title' => substr($content, 0, 60), 'meta_desc' => substr($content, 0, 155)];
    }
}
?>