<?php
// NLP temelli arama niyeti belirleyici
function detect_intent($keyword) {
    $commercial_keywords = ['satın al', 'fiyat', 'kupon', 'indirim'];
    $informational_keywords = ['nedir', 'nasıl', 'fayda', 'avantaj'];

    foreach ($commercial_keywords as $kw) {
        if (strpos($keyword, $kw) !== false) return 'commercial';
    }
    foreach ($informational_keywords as $kw) {
        if (strpos($keyword, $kw) !== false) return 'informational';
    }
    return 'neutral';
}
?>