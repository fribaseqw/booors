<?php
class ImageGenerator {
    public static function create($content) {
        return "https://dummyimage.com/600x400/000/fff&text=" . urlencode(substr($content, 0, 20));
    }
}
?>