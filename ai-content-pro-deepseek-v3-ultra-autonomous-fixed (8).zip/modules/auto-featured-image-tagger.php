<?php
// Unsplash görselleri için alt etiketleri ve SEO etiketlerini otomatik üretir
function generate_image_tags($keyword) {
    return ['alt' => $keyword . " görseli", 'title' => $keyword . " ile ilgili görsel"];
}
?>