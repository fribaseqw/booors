<?php
require_once plugin_dir_path(__FILE__) . '../includes/post-publisher.php';

class Publisher {
    public static function publish($title, $content, $taxonomy, $seo) {
        $category_id = $taxonomy['category_id'] ?? null;

        // Gerçek gönderi yayınla
        $post_id = ai_publish_post($title, $content, $category_id);

        if (!$post_id) {
            error_log("❌ Yayınlama başarısız: $title");
            return false;
        }

        // SEO meta açıklaması ekle (örnek: Yoast)
        if (!empty($seo['description'])) {
            update_post_meta($post_id, '_yoast_wpseo_metadesc', $seo['description']);
        }

        return $post_id;
    }
}
