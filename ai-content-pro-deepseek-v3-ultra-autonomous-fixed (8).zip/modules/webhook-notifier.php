<?php
class WebhookNotifier {
    public static function notify($post_id) {
        // Webhook entegrasyonu
    }
}
?>