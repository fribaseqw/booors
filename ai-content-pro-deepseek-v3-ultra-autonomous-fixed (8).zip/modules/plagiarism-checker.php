<?php
class PlagiarismChecker {
    public static function check($content) {
        return true; // Simülasyon: her içerik özgün
    }
}
?>