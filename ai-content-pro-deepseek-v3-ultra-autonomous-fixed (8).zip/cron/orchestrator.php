<?php
// WordPress çekirdeğini yükle
require_once('/home/walloxgu/public_html/yerelkesif.com/wp-load.php');

// Gerekli dosyalar
require_once plugin_dir_path(__DIR__) . 'modules/publisher.php';
require_once plugin_dir_path(__DIR__) . 'includes/post-publisher.php';

// Diğer modülleri yükle
require_once __DIR__ . '/../modules/logger.php';
require_once __DIR__ . '/../modules/trends-keyword-fetcher.php';
require_once __DIR__ . '/../modules/content-writer.php';
require_once __DIR__ . '/../modules/taxonomy-generator.php';
require_once __DIR__ . '/../modules/image-generator.php';
require_once __DIR__ . '/../modules/seo-meta-builder.php';
require_once __DIR__ . '/../modules/internal-linker.php';
require_once __DIR__ . '/../modules/plagiarism-checker.php';
require_once __DIR__ . '/../modules/silo-builder.php';
require_once __DIR__ . '/../modules/webhook-notifier.php';
require_once __DIR__ . '/../modules/performance-tracker.php';

Logger::log("⏳ İçerik üretim süreci başladı...");

// Anahtar kelimeleri çek
$keywords = TrendsKeywordFetcher::fetch();

foreach ($keywords as $keyword) {
    $content = ContentWriter::generate($keyword);

    if (!$content || stripos($content, 'başarısız') !== false) {
        Logger::log("⚠️ İçerik üretilemedi: $keyword");
        continue;
    }

    $title = $keyword;

    // Diğer verileri oluştur
    $taxonomy = TaxonomyGenerator::assign($content);
    $image_url = ImageGenerator::create($content);
    $seo = SeoMetaBuilder::build($content);
    InternalLinker::link($content);

    // Kopya kontrolü
    if (!PlagiarismChecker::check($content)) {
        Logger::log("❌ Kopya içerik bulundu: $keyword");
        continue;
    }

    // Silo yapısını kur
    SiloBuilder::organize($content);

    // ✅ Gerçek yayınlama burada gerçekleşiyor
    $post_id = Publisher::publish($title, $content, $taxonomy, $seo);

    if (!$post_id) {
        Logger::log("❌ Yayınlama başarısız: $title");
        continue;
    }

    Logger::log("✅ Yayınlandı: $title (ID: $post_id)");

    // Bildirim & performans
    WebhookNotifier::notify($post_id);
    PerformanceTracker::track($post_id);
}

Logger::log("🎉 İçerik üretim süreci tamamlandı.");
