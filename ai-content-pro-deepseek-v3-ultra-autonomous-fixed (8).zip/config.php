<?php
// config.php - Gelişmiş içerik bot modülü yapılandırması

return [
    'deepseek_api_key' => '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',
    'copyleaks_api_key' => '19ac377f-8902-4427-9b65-b93e2d8f2254',
    'unsplash_api_key' => 'JrCn_VKaR5Yc4QPyBUXvaBS22q9HVG_qXznh99LpgkQ',
    'default_language' => 'tr',
    'auto_post_interval' => 180, // dakika cinsinden içerik üretim sıklığı
];

