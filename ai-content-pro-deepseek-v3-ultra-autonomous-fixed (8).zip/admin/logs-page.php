<?php
// Log sayfası - içerik üretim geçmişi görüntülenir
function aipdsp_logs_page() {
    $log_file = plugin_dir_path(__FILE__) . '../logs/content-log.txt';
    echo '<div class="wrap"><h1>İçerik Botu Logları</h1><pre>';
    if (file_exists($log_file)) {
        echo htmlspecialchars(file_get_contents($log_file));
    } else {
        echo 'Henüz log verisi bulunmamaktadır.';
    }
    echo '</pre></div>';
}
