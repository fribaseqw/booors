<?php
// Ayarlar sayfası - DeepSeek, Copyleaks, Unsplash API ayarları
function aipdsp_settings_page() {
    ?>
    <div class="wrap">
        <h1>AI Content Pro Ayarları</h1>
        <form method="post" action="options.php">
            <?php
                settings_fields('aipdsp_settings_group');
                do_settings_sections('aipdsp_settings_group');
                ?>
            <table class="form-table">
                <tr valign="top">
                <th scope="row">DeepSeek API Key</th>
                <td><input type="text" name="deepseek_api_key" value="<?php echo esc_attr(get_option('deepseek_api_key')); ?>" /></td>
                </tr>
                <tr valign="top">
                <th scope="row">Copyleaks API Key</th>
                <td><input type="text" name="copyleaks_api_key" value="<?php echo esc_attr(get_option('copyleaks_api_key')); ?>" /></td>
                </tr>
                <tr valign="top">
                <th scope="row">Unsplash API Key</th>
                <td><input type="text" name="unsplash_api_key" value="<?php echo esc_attr(get_option('unsplash_api_key')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
